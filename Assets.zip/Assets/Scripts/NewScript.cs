using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class NewScript : MonoBehaviour
{
    public InputField squareLength;
    public Canvas canvasToHide;
    private int rows =1;
    private int cols = 1;
    public Text TextField;

    float scaleall=10;
    float sideLength=0;

    Vector2 topLeftPoint;
    Vector2 playerTopLeft;
    Vector3 playerPosition;
    Vector3 Newposition;


    public float TopLeftVertexX=0;
    public float TopLeftVertexY=0;
    public float TopRightVertexX=0;
    public float TopRightVertexY=0;
    public float BottomLeftVertexX=0;
    public float BottomLeftVertexY=0;
    public float BottomRightVertexX=0;
    public float BottomRightVertexY=0;

    GameObject player;
    public string movementType="up";
    void Start()
    {
        if(rows>1 && cols>1){
        TextField.text="0";
        RectTransform panelRectTransform = GetComponent<RectTransform>();
        Vector2 panelDimensions = panelRectTransform.sizeDelta;
        //panelDimensions.x=28;
        sideLength=panelDimensions.x/rows;
        //sideLength=720/rows;
        Debug.Log("sideLength:"+sideLength);
        Debug.Log("PanelDimension:"+panelDimensions.x);

        Vector3[] panelVertices = new Vector3[4];
        panelRectTransform.GetWorldCorners(panelVertices);
        for (int i = 0; i < panelVertices.Length; i++)
        {
            Vector3 vertex = panelVertices[i];
            Debug.Log("Vertex " + i + ": " + vertex);
        }
        //Debug.Log("X:"+panelVertices[0].x+"Y:"+panelVertices[0].y);
        int xy=178;
        if(rows > 4 )
            xy=110;
        topLeftPoint=new Vector2(panelVertices[0].x,panelVertices[0].y+xy);
        //topLeftPoint=new Vector2(-15,-20);
        //playerTopLeft=topLeftPoint;
        GenerateGrid();}
    }
    private void GenerateGrid()
    {
        Debug.Log(TextField.text);
        GameObject referenceTile = Instantiate(Resources.Load("Square") as GameObject);
        GameObject referenceTile2 = Instantiate(Resources.Load("Square") as GameObject);
       
        SpriteRenderer spriteRenderer = referenceTile2.GetComponent<SpriteRenderer>();
        if (spriteRenderer != null && spriteRenderer.sprite != null)
        {
            Bounds bounds = spriteRenderer.sprite.bounds;
            Vector3 size = bounds.size;
            //Debug.Log("Dimensions: " + size.x + " x " + size.y);
            scaleall=sideLength*sideLength;
            scaleall=(scaleall/(size.x*size.x));
            scaleall = Mathf.Sqrt(scaleall);
            //scaleall = Mathf.Sqrt(scaleall);
           //Debug.Log("Scale: " + scaleall );
        }
        else
        {
            Debug.LogError("SpriteRenderer or sprite not found on referenceTile");
        }
        GameObject referenceTile1 = Instantiate(Resources.Load("Square1") as GameObject);
        Transform referenceTransform = referenceTile1.transform;

        float backupTopLeftx=topLeftPoint.x;
        float backupTopLefty=topLeftPoint.y;

        for (int row = 0; row < rows; row++)
        {
            topLeftPoint.y=backupTopLefty;
            for (int col = 0; col <cols; col++)
            {
               if((row+col)%2==0)
                {
                    GameObject tile = Instantiate(referenceTile, transform);
                    
                    Vector2 topRightPoint = new Vector2(topLeftPoint.x + sideLength, topLeftPoint.y);
                    Vector2 bottomLeftPoint = new Vector2(topLeftPoint.x, topLeftPoint.y - sideLength);
                    Vector2 bottomRightPoint = new Vector2(topLeftPoint.x + sideLength, topLeftPoint.y - sideLength);
                
                    float xcoordinate = (topLeftPoint.x + topRightPoint.x + bottomLeftPoint.x + bottomRightPoint.x) / 4f;
                    float ycoordinate = (topLeftPoint.y + topRightPoint.y + bottomLeftPoint.y + bottomRightPoint.y) / 4f;

                    Vector3 position = new Vector3(xcoordinate, ycoordinate, 0f);
                    tile.transform.position = position;

                    ////Foe edges borers only
                    if(row==0 || row==rows-1 || col==0 || col==cols-1)
                        tile.SetActive(true);
                    else
                        tile.SetActive(false);

                    if(row==0 && col==0)
                    {
                        playerPosition=new Vector3(xcoordinate, ycoordinate, -1) ; 
                    }
                    tile.transform.localScale = new Vector2(scaleall, scaleall);
                    //Debug.Log("UpperScale:"+scaleall);
                    tile.name = row.ToString() + col.ToString();

                    if(row==0 && col==0)//BottomLeftVertex
                    {
                        BottomLeftVertexX=xcoordinate;
                        BottomLeftVertexY=ycoordinate;
                        //playerPosition=new Vector3(BottomLeftVertexX, BottomLeftVertexY, -1);
                    }
                    if(row==rows-1 && col==0)//BottomRightVertex
                    {
                        BottomRightVertexX=xcoordinate;
                        BottomRightVertexY=ycoordinate;
                    }
                    if(row==0 && col==cols-1)//TopLeftVertex
                    {
                        TopLeftVertexX=xcoordinate;
                        TopLeftVertexY=ycoordinate;
                    }
                    if(row==rows-1 && col==cols-1)//TopRightVertex
                    {
                        TopRightVertexX=xcoordinate;
                        TopRightVertexY=ycoordinate;

                    }
                }
                else
                {
                    GameObject tile1 = Instantiate(referenceTile1, transform);
                    Vector2 topRightPoint = new Vector2(topLeftPoint.x + sideLength, topLeftPoint.y);
                    Vector2 bottomLeftPoint = new Vector2(topLeftPoint.x, topLeftPoint.y - sideLength);
                    Vector2 bottomRightPoint = new Vector2(topLeftPoint.x + sideLength, topLeftPoint.y - sideLength);
                    float xcoordinate = (topLeftPoint.x + topRightPoint.x + bottomLeftPoint.x + bottomRightPoint.x) / 4;
                        float ycoordinate = (topLeftPoint.y + topRightPoint.y + bottomLeftPoint.y + bottomRightPoint.y) / 4;
                        
                        Vector2 position = new Vector2(xcoordinate, ycoordinate);
                        tile1.transform.position = position;

                        tile1.transform.localScale = new Vector2(scaleall, scaleall);

                        ////Foe Edges Norders only
                        if(row==0 || row==rows-1 || col==0 || col==cols-1)
                            tile1.SetActive(true);
                        else
                            tile1.SetActive(false);

                        tile1.name = row.ToString() + col.ToString();

                        if(row==0 && col==0)//BottomLeftVertex
                        {
                            BottomLeftVertexX=xcoordinate;
                            BottomLeftVertexY=ycoordinate;
                        }
                        if(row==rows-1 && col==0)//BottomRightVertex
                        {
                            BottomRightVertexX=xcoordinate;
                            BottomRightVertexY=ycoordinate;
                        }
                        if(row==0 && col==cols-1)//TopLeftVertex
                        {
                            TopLeftVertexX=xcoordinate;
                            TopLeftVertexY=ycoordinate;
                        }
                        if(row==rows-1 && col==cols-1)//TopRightVertex
                        {
                            TopRightVertexX=xcoordinate;
                            TopRightVertexY=ycoordinate;
                        }
                }
                topLeftPoint.y+=sideLength;
            }
            topLeftPoint.x+=sideLength;
        }

        player = Instantiate(Resources.Load("player") as GameObject);
        //GameObject player = Instantiate(Resources.Load("player") as GameObject);
        SpriteRenderer spriteRenderer1 = player.GetComponent<SpriteRenderer>();
        if (spriteRenderer1 != null && spriteRenderer1.sprite != null)
        {
            Bounds bounds = spriteRenderer1.sprite.bounds;
            Vector3 sizeplayer = bounds.size;
        }
        player.transform.position = playerPosition;
        player.transform.localScale = new Vector2(2*scaleall, 2*scaleall);
      
        Destroy(referenceTile);
        Destroy(referenceTile1);
        Destroy(referenceTile2);
    }
     public void SizeButton()
    {
        rows=int.Parse(squareLength.text);
        cols=rows;
        //Tiggle
        //canvasToHide.gameObject.SetActive(!canvasToHide.gameObject.activeSelf);
        canvasToHide.gameObject.SetActive(false);
        Start();
    }
    public void DiceRolled()
    {
        System.Random random = new System.Random();
        int randomNumber = random.Next(1, 7);
        TextField.text = randomNumber.ToString();
        
        StartCoroutine(MovePlayer(randomNumber));
    }
    IEnumerator MovePlayer(int randomNumber)
    {
        for(int dice=1;dice<=randomNumber ;dice++)
        {


            if((float)Math.Floor(playerPosition.x)==(float)Math.Floor(BottomLeftVertexX) && (float)Math.Floor(playerPosition.y)==(float)Math.Floor(BottomLeftVertexY))
            {
                movementType="up";
              //  Debug.Log("BottomLeftPeHaii");
            }
            if((float)Math.Floor(playerPosition.x)==(float)Math.Floor(BottomRightVertexX) && (float)Math.Floor(playerPosition.y)==(float)Math.Floor(BottomRightVertexY))
            {
                movementType="left";
                //Debug.Log("BottomRightPeHaii");
            }
            if((float)Math.Floor(playerPosition.x)==(float)Math.Floor(TopLeftVertexX) && (float)Math.Floor(playerPosition.y)==(float)Math.Floor(TopLeftVertexY))
            {
                movementType="right";
                //Debug.Log("TopLeftVertext PeeHaiii");
            }
            if((float)Math.Floor(playerPosition.x)==(float)Math.Floor(TopRightVertexX) && (float)Math.Floor(playerPosition.y)==(float)Math.Floor(TopRightVertexY))
            {
                movementType="down";
                //Debug.Log("TopRightVertexPe Haiiiiiiii");
            }

            Newposition = playerPosition;
            if (movementType == "up")
            {
                Newposition.y += sideLength;
                yield return StartCoroutine(Move(playerPosition, Newposition));
            }
            else if (movementType == "down")
            {
                Newposition.y -= sideLength;
                yield return StartCoroutine(Move(playerPosition, Newposition));
            }
            else if (movementType == "left")
            {
                Newposition.x -= sideLength;
               yield return  StartCoroutine(Move(playerPosition, Newposition));
            }
            else if (movementType == "right")
            {
                Newposition.x += sideLength;
               yield return  StartCoroutine(Move(playerPosition, Newposition));//2323232323
            }
            else
            { 

            }
             //Debug.Log("Position");
             playerPosition = Newposition;
             player.transform.position = playerPosition; 
        }

    }
    IEnumerator Move(Vector3 start, Vector3 end)
    {
        float duration = 0.30f;
        float elapsedTime = 0f;
        while (elapsedTime < duration)
        {
            player.transform.position = Vector3.Lerp(start, end, elapsedTime / duration);
            elapsedTime += Time.deltaTime;
            yield return null;
        }
    }
}

