using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class camera : MonoBehaviour
{
    public Canvas canvas;

    float x;
    float y;
    // Start is called before the first frame update
    void Start()
    {
        gameObject.name="MAhmad";
        Debug.Log(canvas.transform.position.x);
        Debug.Log(canvas.transform.position.y);

        RectTransform canvasRect = canvas.GetComponent<RectTransform>();
        float canvasWidth = canvasRect.rect.width;
        Debug.Log("Canvas Width: " + canvasWidth);

       // Vector3 current=gameObject.transform.position;
        //Debug.Log("CameraX"+current.position.x);
        //Debug.Log("CameraY"+current.position.y);
       
       // gameObject.transform.position.x=canvas.transform.position.x;
       // gameObject.transform.position.y=canvas.transform.position.y;
       gameObject.transform.position = new Vector3(canvas.transform.position.x, canvas.transform.position.y, canvas.transform.position.z);

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
